import tools
import xbmc
from threading import Thread


class PlayerCnubis(xbmc.Player):
    def __init__(self, *args, **kwargs):
        self.actual_time = 0
        self.total_time = 0
        self.vast = False
        self.check_complete = False
        self.complete = kwargs['list_complete']
        self.headers = kwargs['headers']
        xbmc.Player.__init__(self)

    def PlayAd(self, playlist, start, first, middle, third):
        self.play(playlist)
        self.actual_time = 0

        check_start = False
        check_first = False
        check_middle = False
        check_third = False
        while self.isPlaying():
            self.actual_time = self.getTime()
            self.total_time = self.getTotalTime()
            xbmc.sleep(500)
            if self.actual_time > 0 and not self.vast:
                if not check_start:
                    check_start = True
                    for url_ad in start:
                        t = Thread(target=tools.onlyRequest, kwargs={'url': url_ad, 'headers': self.headers})
                        t.setDaemon(True)
                        t.start()
                elif self.actual_time / self.total_time > 0.25 and not check_first:
                    check_first = True
                    for url_ad in first:
                        t = Thread(target=tools.onlyRequest, kwargs={'url': url_ad, 'headers': self.headers})
                        t.setDaemon(True)
                        t.start()
                elif self.actual_time / self.total_time > 0.50 and not check_middle:
                    check_middle = True
                    for url_ad in middle:
                        t = Thread(target=tools.onlyRequest, kwargs={'url': url_ad, 'headers': self.headers})
                        t.setDaemon(True)
                        t.start()
                elif self.actual_time / self.total_time > 0.75 and not check_third:
                    check_third = True
                    self.vast = True
                    for url_ad in third:
                        t = Thread(target=tools.onlyRequest, kwargs={'url': url_ad, 'headers': self.headers})
                        t.setDaemon(True)
                        t.start()


    def onPlayBackEnded(self):
        tools.log("PlayerCnubis.onPlayBackEnded")
        xbmc.sleep(1000)
        if not self.check_complete:
            self.check_complete = True
            for url_ad in self.complete:
                t = Thread(target=tools.onlyRequest, kwargs={'url': url_ad, 'headers': self.headers})
                t.setDaemon(True)
                t.start()
