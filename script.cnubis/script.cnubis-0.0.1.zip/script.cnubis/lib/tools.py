import os
import re
import urllib2
import xbmc
import xbmcaddon
from BeautifulSoup import BeautifulStoneSoup

__addon = xbmcaddon.Addon(id="script.cnubis")


def openurl(url, headers):
    log("cnubis.tools openurl")
    log("cnubis.tools url=" + url)

    cookiefile = os.path.join(get_userdata(), 'cookies.dat')
    cj = None
    ClientCookie = None
    cookielib = None

    try:
        import cookielib
    except ImportError:
        try:
            import ClientCookie
        except ImportError:
            urlopen = urllib2.urlopen
            Request = urllib2.Request
        else:
            urlopen = ClientCookie.urlopen
            Request = ClientCookie.Request
            cj = ClientCookie.MozillaCookieJar()

    else:
        urlopen = urllib2.urlopen
        Request = urllib2.Request

        try:
            cj = cookielib.MozillaCookieJar()
        except:
            import traceback
            log(traceback.format_exc())
    if cj is not None:
        if os.path.isfile(cookiefile):
            try:
                cj.load(cookiefile, ignore_discard=True)
            except:
                os.remove(cookiefile)

        if cookielib is not None:
            opener = urllib2.build_opener(urllib2.HTTPHandler(debuglevel=True), urllib2.HTTPCookieProcessor(cj))
            urllib2.install_opener(opener)
        else:
            opener = ClientCookie.build_opener(ClientCookie.HTTPCookieProcessor(cj))
            ClientCookie.install_opener(opener)

    req = Request(url, None, headers)

    try:
        handle = urlopen(req)
        cj.save(cookiefile, ignore_discard=True)
        data = handle.read()
    except urllib2.HTTPError, e:
        import traceback
        log(traceback.format_exc())
        data = e.read()
        return data

    info_headers = handle.info()
    log("cnubis.tools Respuesta")
    log("cnubis.tools *************************")
    for header in info_headers:
        log("cnubis.tools " + header + "=" + info_headers[header])

    handle.close()
    log("cnubis.tools *************************")

    return data


def request(a_b):
    return onlyRequest(*a_b)


def onlyRequest(url, headers):
    log("cnubis.tools onlyRequest")
    log("cnubis.tools url=%s" % url)
    try:
        req = urllib2.Request(url, None, headers)
        response = urllib2.urlopen(req, timeout=3)
        data = response.read()
        response.close()
    except:
        import traceback
        log(traceback.format_exc())
        data = ""

    return data


def get_userdata():
    path = xbmc.translatePath(__addon.getAddonInfo('Profile'))

    return path


def log(text):
    try:
        xbmc.log(text)
    except:
        validchars = " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!#$%&'()-@[]^_`{}~."
        stripped = ''.join(c for c in text if c in validchars)
        xbmc.log("(stripped) " + stripped)


def extract_urls(data, impre, start, first, middle, third, complete):
    xml = BeautifulStoneSoup(data, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
    for url in xml.findAll('impression'):
        try:
            url = re.sub('!\[CDATA\[|\]\]', '', url.string)
            if "metric=rsync" not in url and url != "":
                impre.append(url)
        except:
            pass

    for url in xml.findAll('tracking', {"event": "start"}):
        try:
            url = re.sub('!\[CDATA\[|\]\]', '', url.string)
            if url != "":
                start.append(url)
        except:
            pass

    for url in xml.findAll('tracking', {"event": "firstQuartile"}):
        try:
            url = re.sub('!\[CDATA\[|\]\]', '', url.string)
            if url != "":
                first.append(url)
        except:
            pass

    for url in xml.findAll('tracking', {"event": "midpoint"}):
        try:
            url = re.sub('!\[CDATA\[|\]\]', '', url.string)
            if url != "":
                middle.append(url)
        except:
            pass

    for url in xml.findAll('tracking', {"event": "thirdQuartile"}):
        try:
            url = re.sub('!\[CDATA\[|\]\]', '', url.string)
            if url != "":
                third.append(url)
        except:
            pass

    for url in xml.findAll('tracking', {"event": "complete"}):
        try:
            url = re.sub('!\[CDATA\[|\]\]', '', url.string)
            if url != "":
                complete.append(url)
        except:
            pass

    return impre, start, first, middle, third, complete


def extract_tag(data, tag):
    xml = BeautifulStoneSoup(data, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
    tag = xml.find(tag).string

    return tag


def extract_mediafile(data):
    xml = BeautifulStoneSoup(data, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
    url = ""
    if "video/mp4" in data:
        url = xml.find('mediafile', {'type': 'video/mp4'}).string
    if url == "" and "video/webm" in data:
        url = xml.find('mediafile', {'type': 'video/webm'}).string
    if url == "" and "video/x-flv" in data:
        url = xml.find('mediafile', {'type': 'video/x-flv'}).string

    return url


def extract_asset(data):
    xml = BeautifulStoneSoup(data, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
    url = ""
    if "video/mp4" in data:
        asset = xml.find('asset', {'type': 'video/mp4'})
        url = asset['url']
    if url == "" and "video/webm" in data:
        asset = xml.find('asset', {'type': 'video/webm'})
        url = asset['url']
    if url == "" and "video/x-flv" in data:
        asset = xml.find('asset', {'type': 'video//x-flv'})
        url = asset['url']

    return url


def extract_url_from_swf(data, headers):
    xml = BeautifulStoneSoup(data, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
    url_swf = xml.find('mediafile', {'type': 'application/x-shockwave-flash'}).string
    redirect_xml = re.findall('adData=([^&]+)&', url_swf, flags=re.DOTALL)[0]
    if redirect_xml != "":
        data = openurl(redirect_xml, headers=headers)
        url = extract_asset(data)
    else:
        url = ""

    return url
